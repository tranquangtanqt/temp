import { Body, Controller, ForbiddenException, Get, Post, UseFilters } from '@nestjs/common';
import { ApiBearerAuth } from '@nestjs/swagger';
import { ApiTags } from '@nestjs/swagger/dist';
import { HttpExceptionFilter } from 'src/common/filters/http-exception.filter';
import { Roles } from '../common/decorators/roles.decorator';
import { CatsService } from './cats.service';
import { CreateCatDto } from './dto/create-cat.dto';
import { Cat } from './interfaces/cat.interface';

// @UseGuards(RolesGuard)
@Controller('cats')
@ApiBearerAuth()
@ApiTags('cats')
export class CatsController {
  constructor(private readonly catsService: CatsService) {}

  @Post()
  @Roles('admin')
  async create(@Body() createCatDto: CreateCatDto) {
    this.catsService.create(createCatDto);
  }

  @Get()
  // @UseFilters(new HttpExceptionFilter())
  async findAll(): Promise<Cat[]> {
    // return this.catsService.findAll();
    throw new ForbiddenException();
    
  }

  // @Get(':id')
  // findOne(
  //   @Param('id', new ParseIntPipe())
  //   id: number,
  // ) {
  //   // get by ID logic
  // }
}
