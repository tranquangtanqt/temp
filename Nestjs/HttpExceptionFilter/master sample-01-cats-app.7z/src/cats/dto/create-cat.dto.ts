import { ApiProperty } from '@nestjs/swagger/dist';
import { IsInt, IsString } from 'class-validator';

export class CreateCatDto {
  @IsString()
  @ApiProperty({ example: "name", description: 'The age of the Cat' })
  readonly name: string;

  @IsInt()
  @ApiProperty({ example: 1, description: 'The age of the Cat' })
  readonly age: number;

  @IsString()
  @ApiProperty({ example: "123", description: 'The age of the Cat' })
  readonly breed: string;
}
